async function loadIndex(){
  const res = await fetch('/search.json', { cache: 'no-store' });
  return await res.json();
}
function render(results){
  const box = document.getElementById('results');
  if (!results.length) { box.innerHTML = '<p class="meta">No results.</p>'; return; }
  box.innerHTML = results.map(r => `
    <a class="card" href="${r.url}">
      <h3>${r.title}</h3>
      <div class="meta">${r.date || ''} • ${r.lang?.toUpperCase() || ''}</div>
      <p>${r.excerpt || ''}</p>
      <div>${(r.tags || []).map(t=>`<span class="tag">#${t}</span>`).join('')}</div>
    </a>
  `).join('');
}
async function runSearch(q){
  const idx = await loadIndex();
  const query = q.trim().toLowerCase();
  const results = idx.filter(item => {
    const hay = (item.title + ' ' + (item.excerpt||'') + ' ' + (item.tags||[]).join(' ')).toLowerCase();
    return hay.includes(query);
  });
  render(results);
}
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('searchInput');
  input && input.addEventListener('input', e => runSearch(e.target.value));
  runSearch('');
});
