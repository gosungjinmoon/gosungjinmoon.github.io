---
title: "Build Your Own Email Subscribe with n8n"
date: 2025-10-20
lang: en
tags: [automation]
---
Connect a custom form to an n8n webhook and send welcome emails.
