---
title: "이메일 구독"
permalink: /ko/subscribe/
layout: default
lang: ko
---
<h2>📬 이메일 구독</h2>
<p>새 글과 유용한 자료를 이메일로 받아보세요.</p>
<form id="subForm">
  <input type="email" name="email" class="input" placeholder="이메일 입력" required>
  <input type="text" name="name" class="input" placeholder="이름(선택)">
  <button class="button" type="submit">구독하기</button>
</form>
<p id="msg" class="meta"></p>
<script>
  document.getElementById('subForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    const endpoint = "{{ site.data.theme.integrations.n8n_webhook_subscribe }}";
    try {
      const res = await fetch(endpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      document.getElementById('msg').textContent = res.ok ? "✅ 구독 완료! 환영 메일을 확인해 주세요." : "⚠️ 오류가 발생했습니다.";
      if (res.ok) e.target.reset();
    } catch(e){ document.getElementById('msg').textContent = "🚫 네트워크 오류: " + e.message; }
  });
</script>
