# GoFunWith Blog v4 — Trendy Multilingual + Search + n8n Subscribe + OAuth

## What’s new in v4
- Redesigned theme (glass + gradient hero), refined mobile UX
- Faster search via `/search.json` (client-side)
- Tag pages + on-list tag chip filters
- Email subscribe via n8n webhook (own form)
- GA4-ready, Cloudflare-ready, OAuth(worker) example

## Quick Start
1. Upload all files to `<username>.github.io` repository root
2. Settings → Pages → Deploy from a branch → `main` / `(root)`
3. Edit `_data/theme.yml`: GA4 measurement id + n8n webhook
4. (Optional) Set `CNAME` with your custom domain

## n8n webhook payload
```json
{ "email": "user@example.com", "name": "Eric" }
```

## OAuth Worker (optional)
```bash
cd admin/worker
wrangler secret put GITHUB_CLIENT_ID
wrangler secret put GITHUB_CLIENT_SECRET
wrangler deploy
```
Then update `admin/callback.html` with your Worker URL.
