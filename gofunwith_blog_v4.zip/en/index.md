---
title: "Home — GoFunWith"
permalink: /en/
lang: en
---
{% include components/hero.html %}
<h2>Latest Posts</h2>
<section class="grid">
  {% assign posts = site.en | sort: 'date' | reverse %}
  {% for p in posts limit:12 %}
    <a class="card" href="{{ p.url | relative_url }}" data-tags="{{ p.tags | join: ',' }}">
      <h3>{{ p.title }}</h3>
      <div class="meta">{{ p.date | date: "%Y-%m-%d" }}</div>
      <p>{{ p.excerpt | strip_html | truncate: 160 }}</p>
      <div>{% for t in p.tags %}<span class="tag">#{{ t }}</span>{% endfor %}</div>
    </a>
  {% endfor %}
</section>
{% include components/tag-filter.html %}
