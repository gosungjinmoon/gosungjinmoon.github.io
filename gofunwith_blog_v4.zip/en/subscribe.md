---
title: "Email Subscription"
permalink: /en/subscribe/
layout: default
lang: en
---
<h2>📬 Email Subscription</h2>
<p>Get new posts and resources via email.</p>
<form id="subForm">
  <input type="email" name="email" class="input" placeholder="Email" required>
  <input type="text" name="name" class="input" placeholder="Name (optional)">
  <button class="button" type="submit">Subscribe</button>
</form>
<p id="msg" class="meta"></p>
<script>
  document.getElementById('subForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    const endpoint = "{{ site.data.theme.integrations.n8n_webhook_subscribe }}";
    try {
      const res = await fetch(endpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      document.getElementById('msg').textContent = res.ok ? "✅ Subscribed! Please check your inbox." : "⚠️ Something went wrong.";
      if (res.ok) e.target.reset();
    } catch(e){ document.getElementById('msg').textContent = "🚫 Network error: " + e.message; }
  });
</script>
