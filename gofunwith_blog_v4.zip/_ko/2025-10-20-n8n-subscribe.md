---
title: "n8n으로 자체 이메일 구독 만들기"
date: 2025-10-20
lang: ko
tags: [automation]
---
n8n webhook으로 구독 폼을 직접 연결합니다.
