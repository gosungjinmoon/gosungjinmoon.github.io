---
title: "n8n으로 이메일 구독 자동화 시작하기"
date: 2025-10-18
lang: ko
tags: [automation]
---
n8n 웹훅으로 이메일 구독자를 수집하고, 환영 메일을 자동 발송합니다.
