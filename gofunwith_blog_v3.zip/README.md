# GoFunWith Blog v3 — Trendy Multilingual + Search + n8n Subscribe + OAuth

## Features
- KO/EN bilingual structure (separate collections)
- Trendy UI: hero gradient, glass header, dark/light toggle
- Tag archive pages + client-side tag filter
- Search page via `/search.json` (no plugins needed)
- Email subscription page → n8n webhook (no Formspree)
- GitHub OAuth via Cloudflare Worker
- Cloudflare-ready custom domain

## Quick Start
1. Upload to `<username>.github.io`
2. `_data/theme.yml` → set GA4 + n8n webhook
3. (Optional) `CNAME` → `blog.gofunwith.com`
4. Settings → Pages → Branch `main` / `(root)`

## n8n Webhook (subscribe)
Expected payload:
```json
{ "email": "user@example.com", "name": "Eric" }
```
Recommended workflow:
Webhook → Validate → Google Sheets (append) → Email (welcome) → Respond 200

## GitHub OAuth (Cloudflare Worker)
```bash
cd admin/worker
wrangler secret put GITHUB_CLIENT_ID
wrangler secret put GITHUB_CLIENT_SECRET
wrangler deploy
```
Update `admin/callback.html` with your Worker URL & your OAuth app callback URL.

## Search
- `search.json` built by Liquid: merges `site.ko` and `site.en`
- `search.html` + `assets/js/search.js` filters client-side

## Tags
- Create pages under `/ko/tags/<tag>.md` and `/en/tags/<tag>.md` using layout `tag`
- Tag chips filter posts instantly on list pages
