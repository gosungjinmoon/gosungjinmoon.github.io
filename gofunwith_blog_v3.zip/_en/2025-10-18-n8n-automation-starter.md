---
title: "Start Email Subscription Automation with n8n"
date: 2025-10-18
lang: en
tags: [automation]
---
Collect subscribers via webhook and send a welcome email automatically.
