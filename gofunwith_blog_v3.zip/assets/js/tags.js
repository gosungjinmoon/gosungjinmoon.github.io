document.addEventListener('DOMContentLoaded', () => {
  const chips = document.querySelectorAll('[data-tag-chip]');
  const cards = document.querySelectorAll('[data-tags]');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const t = chip.dataset.tagChip;
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      cards.forEach(card => {
        const tags = card.dataset.tags || '';
        card.style.display = tags.includes(t) ? 'block' : 'none';
      });
    });
  });
});
