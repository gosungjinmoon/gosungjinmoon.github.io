(function(){
  const root = document.documentElement;
  const saved = localStorage.getItem('theme');
  if (!saved) {
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
  } else { root.setAttribute('data-theme', saved); }
  const toggle = document.getElementById('themeToggle');
  toggle && toggle.addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
  });
  const ham = document.getElementById('hamburger');
  const nav = document.getElementById('mainNav');
  ham && ham.addEventListener('click', () => nav.classList.toggle('open'));
})();
