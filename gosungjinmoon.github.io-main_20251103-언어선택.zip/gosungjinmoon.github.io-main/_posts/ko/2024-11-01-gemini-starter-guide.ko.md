---
layout: post
title: "초보자를 위한 Gemini API 시작 가이드"
date: 2024-11-01 10:00:00 +0900
categories: [Tech, AI]
tags: [gemini, api, tutorial]
lang: ko
ref: gemini-starter-guide
---
이 글에서는 Google의 강력한 AI 모델인 Gemini API를 시작하는 가장 간단한 방법을 알아봅니다.
